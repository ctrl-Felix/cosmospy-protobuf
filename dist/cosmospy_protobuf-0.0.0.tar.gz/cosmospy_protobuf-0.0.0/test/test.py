import grpc
import cosmospy_protobuf.cosmos.bank.v1beta1.query_pb2_grpc as query_pb2_grpc
import cosmospy_protobuf.cosmos.bank.v1beta1.query_pb2 as query_pb2
import cosmospy_protobuf.ibc.core.channel.v1.query_pb2_grpc as ibc_query_pb2_grpc
import cosmospy_protobuf.ibc.core.channel.v1.query_pb2 as ibc_query_pb2

host = "osmosis.strange.love"
port = "9090"

c = grpc.insecure_channel('{}:{}'.format(host, port))
stub = ibc_query_pb2_grpc.QueryStub(c)


r = stub.PacketCommitments(ibc_query_pb2.QueryPacketCommitmentsRequest(port_id="transfer", channel_id="channel-141"))
print(r.commitments)